
var profile = []
function addProFile(e) {
    profile.push(e)
}
function getProfile() {
    return profile
}
export{addProFile,getProfile}